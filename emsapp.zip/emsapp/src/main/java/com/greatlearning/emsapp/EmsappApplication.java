package com.greatlearning.emsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsappApplication.class, args);
	}

}
