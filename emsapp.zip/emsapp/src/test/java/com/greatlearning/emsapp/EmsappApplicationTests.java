package com.greatlearning.emsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsappApplicationTests {

	@Test
	void contextLoads() {
	}

}
